from run import *
text='aaabbc'
code=encode(text)
decoded=decode(code)
print(code)